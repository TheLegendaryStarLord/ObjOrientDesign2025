package smartbox.components;

public interface CommandProcessor {
	public String execute(String cmmd) throws Exception;
}