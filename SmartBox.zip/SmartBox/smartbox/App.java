package smartbox;

public interface App {
    void main() throws Exception;
}