package mvc;

import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

public abstract class Model extends Publisher implements Serializable {
    private static final long serialVersionUID = 1L;

    private List<Subscriber> subscribers = new ArrayList<>();
    private String fileName = null;
    private Boolean unsavedChanges = false;
    public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    public Boolean getUnsavedChanges() {
        return unsavedChanges;
    }
    public void setUnsavedChanges(Boolean unsavedChanges) {
        this.unsavedChanges = unsavedChanges;
    }

  
    public void subscribe(Subscriber s){
        if (!subscribers.contains(s)){
            subscribers.add(s);
        }
    }
    
    
    public void unsubscribe(Subscriber s){
        subscribers.remove(s);
    }
    
    public void changed() {
        unsavedChanges = true;
        notifySubscribers();
    }

}