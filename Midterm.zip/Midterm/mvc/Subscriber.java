package mvc;

public interface Subscriber
{
    void update();
}
