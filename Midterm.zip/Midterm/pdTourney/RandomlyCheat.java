package pdTourney;


/**
 * Write a description of class RandomlyCheat here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import java.util.Random;

public class RandomlyCheat implements Strategy
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class RandomlyCheat
     */
    public RandomlyCheat()
    {
        // initialise instance variables
        x = 0;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public boolean choose()
    {
        Random rand = new Random();
        x = rand.nextInt(1);
        boolean choice = true;
        if (x == 1) choice = true;
        else{ choice = false;}
        return choice;
    }
}
