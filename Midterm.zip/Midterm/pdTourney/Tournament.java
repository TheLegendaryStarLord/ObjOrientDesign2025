package pdTourney;


/**
 * Write a description of class Tournament here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Tournament
{
    public Prisoner inmate1;
    public Prisoner inmate2;
    
}
