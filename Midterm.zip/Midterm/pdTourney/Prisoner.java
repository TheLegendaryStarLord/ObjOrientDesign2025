package pdTourney;


/**
 * Write a description of class Prisoner here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Prisoner
{
    // instance variables - replace the example below with your own
    private int score;
    public Strategy strategy;
    
    /**
     * Constructor for objects of class Prisoner
     */
    public Prisoner()
    {
        // initialise instance variables
        score = 0;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void playOnce()
    {
        
    }
}
